dat <- read.delim('data/nutnet_ITS.txt', skip=1, stringsAsFactors=F)
str(dat)

names(dat) <- gsub('barcodelabel.', '', names(dat), fixed=T)
names(dat)
names(dat) <- gsub('.', '', names(dat), fixed=T)
names(dat)


library(dplyr)
mat <- select(dat, -XOTUID)
mat <- as.matrix(mat)
rownames(mat) <- dat$XOTUID
mat <- t(mat)

dat <- data.frame(SampleID=rownames(mat), mat, stringsAsFactors=F)
rm(mat)

samps <- read.csv('data/nutnet_samples.csv', stringsAsFactors=F)
str(samps)
samps$SampleType <- factor(samps$SampleType)
str(samps)

plots <- read.csv('data/nutnet_plots.csv', stringsAsFactors=F)
str(plots)
plots$Treatment <- factor(plots$Treatment, 
                          levels=c('control', 'N', 'P', 'NP'))
str(plots)
levels(plots$Treatment)
summary(plots)


soils <- read.csv('data/nutnet_soildata.csv', stringsAsFactors=F)
str(soils)


df <- full_join(samps, plots)
df <- full_join(df, soils)
df <- full_join(df, dat)
write.csv(df, 'output/nutnet_allData.csv', row.names=F, quote=F)

df$PlotID <- factor(df$PlotID)
df$BlockID <- factor(df$BlockID)


tax <- read.delim('data/nutnet_tax.txt', stringsAsFactors=F)
head(tax)
names(tax)[1] <- 'OTUId'

tax <- tax[!duplicated(tax$OTUId), ]

# devtools::install_github('joey711/phyloseq')

library(phyloseq)

otus <- as.matrix(select(df, starts_with('ITSall')))
rownames(otus) <- df$SampleID

samps <- select(df, SampleID:CP_Enz)
rownames(samps) <- df$SampleID

taxonomy <- as.matrix(select(tax, kingdom:species))
rownames(taxonomy) <- tax$OTUId

phy <- merge_phyloseq(otu_table(otus, taxa_are_rows=F),
                      sample_data(samps),
                      tax_table(taxonomy))

phy <- subset_taxa(phy, kingdom == 'Fungi' & !is.na(phylum))
# write.table(psmelt(phy), 'output/melt_phy.txt', row.names=F)

phy <- subset_samples(phy, sample_sums(phy) >= 26264)


