# load libraries
library(phyloseq)
library(QsRutils)
library(DESeq2)
library(ggplot2)

# prepare data
source('phy_dataPrep.R')


### OTU responses

# plot taxa network
plot_net(phy, type='taxa', 
         point_size=2, point_alpha=0.5, maxdist=0.3, hjust=1)

# plot taxa heatmap (NOT SURE WHY TAXA LABELS ARE NA)
plot_heatmap(phy, method='RDA', distance='euclidean', 
             sample.order='SampleType', sample.label='SampleType')

# convert and analyse using deseq2
deseq2 <- phyloseq_to_deseq2(phy, ~SampleType)
deseq2 <- DESeq(deseq2, test='Wald', fitType='parametric')

# get results and filter significant taxa
res <- results(deseq2, cooksCutoff=F)
sig <- res[which(res$padj < 0.01), ]

# get annotations for significant taxa
sig <- cbind(as(sig, 'data.frame'), 
             as(tax_table(phy)[rownames(sig), ], 'matrix'))
head(sig)
dim(sig)

# check pattern for most frequent OTU
otu <- 'ITSall_OTUa_524'
temp <- data.frame(counts=veganotu(phy)[, otu], 
                   SampleID=names(veganotu(phy)[, otu]), 
                   stringsAsFactors=F)
temp <- left_join(temp, 
                  data.frame(sample_data(phy))[, c('SampleID', 'SampleType')])
temp %>% group_by(SampleType) %>% 
  summarise(mean.counts = mean(counts))

# make plot
x <- tapply(sig$log2FoldChange, sig$genus, function(x)max(x))
x <- sort(x, T)
sig$genus <- factor(as.character(sig$genus), levels=names(x))
ggplot(sig, aes(x=genus, y=log2FoldChange, color=phylum)) + 
  geom_point(size=3) + 
  theme(axis.text.x=element_text(angle=-90, hjust=0, vjust=0.5))

# export dataframe for more analysis / plotting
sig.otus <- data.frame(OTUId=rownames(sig), baseMean=sig$baseMean, 
                       log2FoldChange=sig$log2FoldChange)
sig.otus$color <- ifelse(sig.otus$log2FoldChange < 0, 'green', 'brown')
sig.otus$alpha <- with(sig.otus, abs(log2FoldChange) / max(abs(log2FoldChange)))
summary(sig.otus)



### agglomerating taxa and measuring responses

# agglomerate at the genus level
phy.tax <- tax_glom(phy, taxrank='genus')
phy.tax <- subset_taxa(phy.tax, taxa_sums(phy.tax) >= 1)
phy.tax

# plot taxa network
plot_net(phy.tax, type='taxa', point_label='genus', 
         point_size=2, point_alpha=0.5, maxdist=0.3, hjust=1)

# plot taxa heatmap (NOT SURE WHY TAXA LABELS ARE NA)
plot_heatmap(phy.tax, method='RDA', distance='euclidean', 
             sample.order='SampleType', sample.label='SampleType', 
             taxa.label='family')

# convert and analyse using deseq2
deseq2 <- phyloseq_to_deseq2(phy.tax, ~SampleType)
deseq2 <- DESeq(deseq2, test='Wald', fitType='parametric')

# get results and filter significant taxa
res <- results(deseq2, cooksCutoff=F)
sig <- res[which(res$padj < 0.01), ]

# get annotations for significant taxa
sig <- cbind(as(sig, 'data.frame'), 
             as(tax_table(phy)[rownames(sig), ], 'matrix'))
head(sig)
dim(sig)

# make plot
x <- tapply(sig$log2FoldChange, sig$genus, function(x)max(x))
x <- sort(x, T)
sig$genus <- factor(as.character(sig$genus), levels=names(x))
ggplot(sig, aes(x=genus, y=log2FoldChange, color=phylum)) + 
  geom_point(size=3) + 
  theme(axis.text.x=element_text(angle=-90, hjust=0, vjust=0.5))

# export dataframe for more analysis / plotting
sig.tax <- data.frame(OTUId=rownames(sig), baseMean=sig$baseMean, 
                       log2FoldChange=sig$log2FoldChange)
sig.tax$color <- ifelse(sig.tax$log2FoldChange < 0, 'green', 'brown')
sig.tax$alpha <- with(sig.tax, abs(log2FoldChange) / max(abs(log2FoldChange)))
summary(sig.tax)
