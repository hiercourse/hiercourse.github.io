
# load library
library(tidyr)

# read data
dat <- read.csv('data/k__Fungi.csv', stringsAsFactors=F)
context <- read.csv('data/contextual.csv', stringsAsFactors=F)

# rename OTUs while keeping representative sequences
dat$repseq <- dat$OTU
dat$OTU <- factor(dat$OTU)
levels(dat$OTU) <- paste('OTU', 1:length(levels(dat$OTU)), sep='_')
dat$OTU <- as.character(dat$OTU)

# prepare OTU table
otus <- dat %>% select(Sample.ID, OTU, OTU.Count) %>% 
  spread(key='OTU', value='OTU.Count', fill=0)
