
# load library
library(tidyr)

# read in psmelt data
dat <- read.table('output/melt_phy.txt', header=T, stringsAsFactors=F)
names(dat)

# prepare OTU matrix
otus <- select(dat, OTU:Abundance)
otus <- spread(otus, key='Sample', value='Abundance', fill=0)
dim(otus)
rownames(otus) <- otus$OTU
otus <- as.matrix(select(otus, -OTU))

# prepare taxa matrix
taxa <- select(dat, OTU, kingdom:species)
taxa <- taxa[!duplicated(taxa$OTU), ]
rownames(taxa) <- taxa$OTU
taxa <- as.matrix(select(taxa, -OTU))

# prepare sample matrix
samp <- select(dat, Sample:CP_Enz)
samp <- samp[!duplicated(samp$Sample), ]
rownames(samp) <- samp$Sample
samp$Sample <- NULL

# merge
phy <- merge_phyloseq(otu_table(otus, taxa_are_rows=T), 
                      tax_table(taxa), 
                      sample_data(samp))
