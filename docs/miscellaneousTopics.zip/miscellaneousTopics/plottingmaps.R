
# read in dirty data that we cleaned up (see 'dirtydatacleaning.R')
df <- read.csv('clean.csv')
summary(df)


### plot distribution of trees globally using 'maps' library

# load library
library(maps)

# plot world map in graphics window
# can resize graphics window after plotting and map still looks good
map('world')

# add points to map
with(df, points(lon, lat, pch=16, col="red", cex=0.5))


### plot distribution of trees in Australia using 'oz' library

# load library
library(oz)

# plot Australian map in graphics window
oz()

#add points to map
with(df, points(lon, lat, pch=16, col="red", cex=0.5))

# use 'section' to produce state/regional map (see ?oz, 6 = Tasmania)
oz(section=6)

# this time colour points by 'species' and add legend
with(df, points(lon, lat, pch=16, col=species, cex=0.75))
legend('topright', levels(df$species), col=palette(), pch=16, cex=0.5)


### plot distribution of trees globally using 'plotly' (good for interactive viz)

# load library
library(plotly)

# plot tree locations on world map, colour points by AMT
p <- plot_geo(df, lat = ~lat, lon = ~lon, color = ~AMT) %>%
  layout(geo = list(scope = 'world'))
p

# add species onto markers
p <- p %>% add_markers(text = ~species, hoverinfo = "text")
p


# ### plot distribution of trees regionally using 'ggmap' (NOT YET DEVELOPED)
# 
# # install library from github
# devtools::install_github("dkahle/ggmap", ref = "tidyup", force=TRUE)
# 
# # load library
# library(ggmap)
# 
# 
# get_googlemap(hfeCoor, zoom = 12) %>% ggmap()
# plot_mapbox(maps::canada.cities) %>%
#   add_markers(
#     x = ~long, 
#     y = ~lat, 
#     size = ~pop, 
#     color = ~country.etc,
#     colors = "Accent",
#     text = ~paste(name, pop),
#     hoverinfo = "text"
#   )
