
# Install packages for the course ----------------------------------------------

# To run this, click the 'Source' button to the top-right of this pane in RStudio, or
# run each line individually with Ctrl + Enter.

# install.packages("usethis")      # You should already have 'usethis'

install.packages("tidyverse")      # Core Tidyverse packages
install.packages("remotes")        # Installing packages from GitHub
install.packages("here")           # Flexible directory organisation
install.packages("janitor")        # Fixing data frames
install.packages("plotly")         # Interactive plots for the web



# Install RStudio addins ------------------------------------------------------------

remotes::install_github("daranzolin/ViewPipeSteps", force = TRUE, upgrade = FALSE)  # For debugging pipelines
install.packages("datapasta")      # Paste data as vectors or dataframes



# Install colourblind-friendly theme ------------------------------------------------

# install.packages("rstudioapi")
#
# rstudioapi::addTheme("https://github.com/DesiQuintans/Pebble-safe/releases/download/1.0.0/Pebble-Safe_Dark.rstheme",
#                      apply = TRUE, force = TRUE)

# Switch themes by going to Tools → Global Options → Appearance.
