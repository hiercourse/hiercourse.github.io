
These are the downloadable workshop materials for the HIE Advanced R course,
"Working in the Tidyverse", by Desi Quintans and Jeff Powell.

http://www.hiercourse.com/



CONTENTS:

- Working_in_the_Tidyverse.pdf  The course manual, also available separately.
- working_in_tidyverse.Rproj    RStudio project file. Double-click it to start.
- install_course_packages.R     Run this script to install the course's packages.
- README.md                     This file.

- _answers/                     Solved exercises. Use these to skip ahead.
- _data/                        Raw data files used in the workshop.
- _output/                      A folder for your outputs (spreadsheets, plots).
