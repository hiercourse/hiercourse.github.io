
pdf("output/figure1.pdf")
figure1()
dev.off()

pdf("output/figure2.pdf")
figure2()
dev.off()

pdf("output/figure3.pdf")
figure3()
dev.off()

pdf("output/figure4.pdf")
figure4()
dev.off()

pdf("output/figure5.pdf")
figure5()
dev.off()
