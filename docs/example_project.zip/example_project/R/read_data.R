# read pupae data if you have not already
pupae <- read.csv("data/pupae.csv")


# read in data and split data.frame by species
coweeta <- read.csv("data/coweeta.csv")

# Election data
election <- read.csv("data/dutchelection.csv")
election$Date <- as.Date(election$Date)

# Make data into long format
elect_long <- melt(election, id.vars="Date", 
                   variable.name="party",
                   value.name="vote_percent")

# Weather data
hfemet <- read.csv("data/HFEmet2008.csv", stringsAsFactors=FALSE)

# Convert to a proper DateTime class:
hfemet$DateTime <- mdy_hm(hfemet$DateTime)

# Add the Date :
hfemet$Date <- as.Date(hfemet$DateTime)

# Select one day (a cloudy day in June).
hfemetsubs <- subset(hfemet, Date==as.Date("2008-6-1"))

# VEssel data
vessel <- read.csv("data/vessel.csv")
vesselBase <- subset(vessel, position=="base")
vesselApex <- subset(vessel, position=="apex")
