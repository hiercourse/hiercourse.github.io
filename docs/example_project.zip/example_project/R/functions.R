# SE for the mean
se <- function(x,na.rm=FALSE){
  if(na.rm)x <- x[!is.na(x)]
  sd(x)/sqrt(length(x))
}
