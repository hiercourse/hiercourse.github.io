
figure1 <- function(){
  par(xpd = T, mar = c(5,4,1,7))
  with(coweeta, plot(height ~ DBH, pch=c(1:10)[species]))
  legend(70, 35, levels(coweeta$species), pch=1:10, cex=0.8)
}


figure2 <- function(){
  
  cowsub <- subset(coweeta, species %in% c("acru","bele","caov","qupr"))
  
  ggplot(cowsub, aes(x=height, y=folmass)) + 
    geom_point() + 
    facet_wrap(~species, nrow=2) +
    labs(x="Height (m)", y="Total foliage mass (kg)")
  
}


figure3 <- function(){
  ggplot(elect_long, aes(Date, vote_percent, col=party)) +
    geom_path() + scale_colour_manual(values=rainbow(12)) + 
    ylim(c(0,30)) + 
    labs(x="Date", y="Poll result (%)") +
    theme_bw() +  # Black and white theme
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())
  
}


figure4 <- function(){
  
  par(mfrow=c(1,2), mar=c(5,5,4,1), cex.lab=1.3, xaxs="i", yaxs="i")
  
  # First panel
  hist(vesselBase$vesseldiam, 
       main="Base",
       col="darkgrey",
       xlim=c(0,160), breaks=seq(0,160,by=10),
       xlab=expression(Vessel~diameter~~(mu*m)),
       ylab="Number of vessels")
  
  # Second panel
  hist(vesselApex$vesseldiam, 
       main="Apex",
       col="lightgrey",
       xlim=c(0,160), breaks=seq(0,160,by=10),
       xlab=expression(Vessel~diameter~~(mu*m)),
       ylab="Number of vessels")
  
  
}



figure5 <- function(){
  
  par(mar=c(5,5,2,5), cex.lab=1.2, cex.axis=0.9)
  with(hfemetsubs, plot(DateTime, Tair, type='l',
                        ylim=c(0,20), lwd=2, col="blue",
                        xlab="Time",
                        ylab=expression(T[air]~~(""^"o"*C))))
  par(new=TRUE)
  with(hfemetsubs, plot(DateTime, PAR, type='l', col="red",
                        lwd=2,
                        ylim=c(0,1000),
                        axes=FALSE, ann=FALSE))
  axis(4)
  mtext(expression(PAR~~(mu*mol~m^-2~s^-1)), side=4, line=3, cex=1.2)
  legend("topleft", c(expression(T[air]),"PAR"), lwd=2, col=c("blue","red"),
         bty='n')
  
}