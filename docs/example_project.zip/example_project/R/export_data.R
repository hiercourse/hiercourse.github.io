
# also save to disk
write.csv(hfemetsubs, "output/hfemetsubs.csv", row.names=FALSE)

# export
write.csv(puptab, "output/puptab.csv", row.names=FALSE)
