# Make a table of means and SD of the pupae data
puptab <- summaryBy(Frass + PupalWeight ~ CO2_treatment + T_treatment,
                    FUN=c(mean,sd,se), data=pupae, na.rm=TRUE)



# t.test
pup_ttest <- t.test(Frass ~ Gender, data=pupae)
