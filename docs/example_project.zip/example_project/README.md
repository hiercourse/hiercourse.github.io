
# Example project with sensible folder structure

This folder is an example analysis, with everything organized into separate scripts.

To run the whole analysis, simply 'source' `analysis.R`.

Refer to chapter 9 for some background on why to organize your files this way.

The file 'original_example_script_before_organising.R' is the original file *before* it was reorganized into
folders and separate scripts.


