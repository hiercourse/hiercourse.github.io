


# Table

# Load the doBy package
library(doBy)

# read pupae data if you have not already
pupae <- read.csv("pupae.csv")

# SE for the mean
se <- function(x,na.rm=FALSE){
  if(na.rm)x <- x[!is.na(x)]
  sd(x)/sqrt(length(x))
}

# Make a table of means and SD of the pupae data
puptab <- summaryBy(Frass + PupalWeight ~ CO2_treatment + T_treatment,
                    FUN=c(mean,sd,se), data=pupae, na.rm=TRUE)

library(pander)
pander(puptab, caption = "Table 1. Summary stats for the pupae data, in pander.")

# export
write.csv(puptab, "puptab.csv", row.names=FALSE)

# t.test
pup_ttest <- t.test(Frass ~ Gender, data=pupae)
pander(pup_ttest)




# read in data and split data.frame by species
coweeta <- read.csv("coweeta.csv")

# set plot margins, with extra white space on right side
par(xpd = T, mar = c(5,4,1,7))
with(coweeta, plot(height ~ DBH, pch=c(1:10)[species]))
legend(70, 35, levels(coweeta$species), pch=1:10, cex=0.8)


# Coweeta tree plot
library(ggplot2)
cowsub <- subset(coweeta, species %in% c("acru","bele","caov","qupr"))

ggplot(cowsub, aes(x=height, y=folmass)) + 
  geom_point() + 
  facet_wrap(~species, nrow=2) +
  labs(x="Height (m)", y="Total foliage mass (kg)")


# Election plot
library(reshape2)

election <- read.csv("dutchelection.csv")
election$Date <- as.Date(election$Date)

# Make data into long format
elect_long <- melt(election, id.vars="Date", 
                   variable.name="party",
                   value.name="vote_percent")

# Setting col=party in the aes statement will make a line for each party,
# with a different colour 
ggplot(elect_long, aes(Date, vote_percent, col=party)) +
  geom_path() + scale_colour_manual(values=rainbow(12)) + 
  ylim(c(0,30)) + 
  labs(x="Date", y="Poll result (%)") +
  theme_bw() +  # Black and white theme
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) # No grid lines


# Histogram of vessels
vessel <- read.csv("vessel.csv")
vesselBase <- subset(vessel, position=="base")
vesselApex <- subset(vessel, position=="apex")

par(mfrow=c(1,2), mar=c(5,5,4,1), cex.lab=1.3, xaxs="i", yaxs="i")

# First panel
hist(vesselBase$vesseldiam, 
     main="Base",
     col="darkgrey",
     xlim=c(0,160), breaks=seq(0,160,by=10),
     xlab=expression(Vessel~diameter~~(mu*m)),
     ylab="Number of vessels")

# Second panel
hist(vesselApex$vesseldiam, 
     main="Apex",
     col="lightgrey",
     xlim=c(0,160), breaks=seq(0,160,by=10),
     xlab=expression(Vessel~diameter~~(mu*m)),
     ylab="Number of vessels")


# Weather plot
hfemet <- read.csv("HFEmet2008.csv", stringsAsFactors=FALSE)

# Convert to a proper DateTime class:
library(lubridate)
hfemet$DateTime <- mdy_hm(hfemet$DateTime)

# Add the Date :
hfemet$Date <- as.Date(hfemet$DateTime)

# Select one day (a cloudy day in June).
hfemetsubs <- subset(hfemet, Date==as.Date("2008-6-1"))

# also save to disk
write.csv(hfemetsubs, "hfemetsubs.csv", row.names=FALSE)

par(mar=c(5,5,2,5), cex.lab=1.2, cex.axis=0.9)
with(hfemetsubs, plot(DateTime, Tair, type='l',
                      ylim=c(0,20), lwd=2, col="blue",
                      xlab="Time",
                      ylab=expression(T[air]~~(""^"o"*C))))
par(new=TRUE)
with(hfemetsubs, plot(DateTime, PAR, type='l', col="red",
                      lwd=2,
                      ylim=c(0,1000),
                      axes=FALSE, ann=FALSE))
axis(4)
mtext(expression(PAR~~(mu*mol~m^-2~s^-1)), side=4, line=3, cex=1.2)
legend("topleft", c(expression(T[air]),"PAR"), lwd=2, col=c("blue","red"),
       bty='n')
