# load libraries
library(dplyr)
library(ggplot2)


# read data
election <- read.csv("dutchelection.csv")
election$Date <- as.Date(election$Date)


# Make data into long format
elect_long <- election %>% gather(key="party", value="vote_percent", -Date)
head(elect_long)
tail(elect_long)

# Setting col=party in the aes statement will make a line for each party,
# with a different colour 
p <- ggplot(elect_long, aes(Date, vote_percent, col=party)) +
  geom_path()
p

# specify some options by adding additional layers
p <- ggplot(elect_long, aes(Date, vote_percent, col=party)) +
  geom_path() + 
  scale_colour_manual(values=rainbow(12)) + 
  ylim(c(0,30)) +
  labs(x="Date", y="Poll result (%)") +
  theme_bw() +  # Black and white theme
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) # No grid lines
p

# wrap plot with ggplotly allows hovering text
plotly::ggplotly(p)



# convert back to wide format to show how this is done
elect_wide <- elect_long %>% spread(key='party', value='vote_percent')
str(elect_wide)

# add month to long format version to show another result
elect_long$month <- lubridate::month(elect_long$Date)
elect_wide <- elect_long %>% spread(key='party', value='vote_percent')
str(elect_wide)
