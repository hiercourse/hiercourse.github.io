# load library
library(sp)
library(gstat)
library(scales)

# read in dirty data that we cleaned up (see 'dirtydatacleaning.R')
df <- read.csv('clean.csv')
summary(df)

# work with a subset of the data (Australia and NZ)
df <- subset(df, lon > 135 & lon < 160 & lat < 0) 

# remove NAs (after dropping 'Country') then convert dataframe to SpatialPointsDataFrame
df$Country <- NULL
df <- df[complete.cases(df), ]
coordinates(df) <- ~ lat + lon
head(df)

# look at limits of lat and long
bbox(df)

# look at histogram of spatial distances
hist(dist(attr(df, 'coords')))

# remove rows with duplicate entries (multiple species detected)
df <- df[-zerodist(df)[,1],] 

# fit variogram then plot
t.vgm <- variogram(Tmin ~ 1, data=df) 
t.fit <- fit.variogram(t.vgm, model=vgm(NA, 'Sph', NA, NA))
plot(t.vgm, t.fit)

# create a grid on which to plot predictions
lat <- seq(from=bbox(df)['lat', 'min'], to=bbox(df)['lat', 'max'], by=0.5)
lon <- seq(from=bbox(df)['lon', 'min'], to=bbox(df)['lon', 'max'], by=0.5)
df.grid <- data.frame(lat=rep(lat, times=length(lon)), lon=rep(lon, each=length(lat)))
head(df.grid)
tail(df.grid)
coordinates(df.grid) <- ~ lat + lon

# perform kriging
t.kriged <- krige(Tmin ~ 1, df, df.grid, model=t.fit)

# convert to dataframe, create bins for colours
t.res <- as.data.frame(t.kriged)
t.res$predbin <- cut(t.res$var1.pred, breaks=10)

# set palette with heat colours
palette(alpha(heat.colors(10), 0.5))

# plot prediction
oz()
with(t.res, points(lon, lat, pch=0.01, col=predbin))
legend('topright', levels(t.res$predbin), fill=palette(), title='Tmin')

# plot again, reverse order for levels of new factor (high to low)
levs <- rev(levels(t.res$predbin))
t.res$predbin <- factor(t.res$predbin, levels=levs)
oz()
with(t.res, points(lon, lat, pch=0.01, col=predbin))
legend('topright', levels(t.res$predbin), fill=palette(), title='Tmin')
