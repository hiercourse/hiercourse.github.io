# load library
library(ggplot2)

# read and prepare data
coweeta <- read.csv("coweeta.csv")
cowsub <- subset(coweeta, species %in% c("acru","bele","caov","qupr"))

# plot folmass by height for all species, use colour
p <- ggplot(cowsub, aes(x=height, y=folmass, col=species)) + 
  geom_point() + 
  labs(x="Height (m)", y="Total foliage mass (kg)")
p

# each species in separate plot
p <- p + facet_wrap(~species, nrow=2)
p

# add fitted line and confidence interval to each plot
p <- p + geom_smooth(aes(group=species), method="lm")
p

# stack in one column
p <- p + facet_wrap(~species, nrow=4) + aes(col=NULL)
p

# open new graphics window and write plot to file
quartz('tallplot', width=4, height=8)  # for mac
# windows(width=4, height=8)  # for windows
p
dev.copy2pdf(file='tallplot.pdf')
dev.off()
